using System;
using System.Collections.Generic;
using System.Text;

namespace QImporting.SAPImporting
{
    public static class SAPConstants
    {
        //XML file constants......
        public const string TXT_TABLE_STR = "TABLE: ";

    }
}
