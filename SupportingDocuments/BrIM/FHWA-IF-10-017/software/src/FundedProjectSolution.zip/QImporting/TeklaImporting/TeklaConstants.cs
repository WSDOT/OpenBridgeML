using System;
using System.Collections.Generic;
using System.Text;

namespace TeklaImporting
{
    class TeklaConstants
    {
        public const string XML_GIRDER_ROOT_STR = "//girder";

    }
}
