using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace QTeklaImporting
{
    public partial class fmImporting : Form
    {
        public fmImporting()
        {
            InitializeComponent();
        }

        private void fmImporting_Load(object sender, EventArgs e)
        {

        }
    }
}