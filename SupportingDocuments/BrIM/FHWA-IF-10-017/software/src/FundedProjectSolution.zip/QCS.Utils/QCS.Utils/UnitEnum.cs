using System;
using System.Collections.Generic;
using System.Text;

namespace QCS.Utils
{
    public class UnitEnum
    {
        public const string METER = "m";
        public const string MILLIMETER = "mm";
        public const string FOOT = "ft";
        public const string INCH = "in";
    }
}
